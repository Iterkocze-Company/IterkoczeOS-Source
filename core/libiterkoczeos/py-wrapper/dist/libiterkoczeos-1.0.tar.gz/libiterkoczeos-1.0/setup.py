#!/usr/bin/python3

from distutils.core import setup

setup(name='libiterkoczeos',
      version='1.0',
      description='libiterkoczeos wrapper for Python',
      author='Iterkocze Company',
     )
