The RelaxNG schemas in this directory are available under
under [the W3C Test Suite License](http://www.w3.org/Consortium/Legal/2008/04-testsuite-license.html).

See https://github.com/w3c/its-2.0-testsuite#licensing-information
