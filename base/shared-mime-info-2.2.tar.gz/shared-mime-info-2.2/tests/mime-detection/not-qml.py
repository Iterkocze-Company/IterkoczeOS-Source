from PyQt5 import QtCore

# {
