% Title
% Author

# This is a markdown file...

...with a title block for [Pandoc-flavoured markdown](https://pandoc.org/MANUAL.html#extension-pandoc_title_block)
