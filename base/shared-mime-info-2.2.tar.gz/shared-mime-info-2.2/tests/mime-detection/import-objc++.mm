#import <CoreFoundation/CoreFoundation.h>

void functionName()
{
    [foo methodical:fixIt];
}
