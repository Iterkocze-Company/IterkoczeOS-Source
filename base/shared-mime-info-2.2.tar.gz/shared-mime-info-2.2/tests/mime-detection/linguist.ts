<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>QPushButton</name>
    <message>
        <source>Hello World!</source>
        <translation>Hallo Welt!</translation>
    </message>
</context>
</TS>
