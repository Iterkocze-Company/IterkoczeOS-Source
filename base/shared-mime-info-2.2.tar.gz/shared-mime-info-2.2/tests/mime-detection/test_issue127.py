class Example:

    def __init__(self):
        print("Init.")

if __name__ == "__main__":
    ex = Example()
