This project and its community follow the [Freedesktop.org code of conduct]

[Freedesktop.org code of conduct]: https://www.freedesktop.org/wiki/CodeOfConduct/
