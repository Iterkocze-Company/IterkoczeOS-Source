# SPDX-FileCopyrightText: 2021 Emmanuele Bassi
# SPDX-License-Identifier: GPL-3.0-or-later OR Apache-2.0
